# Student Record Management System (C)

A menu-driven console application in C to manage student records.

## Features
- Add, display, search, update and delete students
- 5 subjects per student (marks 0-100), automatic total (/500) and average %
- Sort by ID or by average marks
- Unique student IDs, input validation, empty-name check
- Records saved permanently in a binary file (`students.dat`)

## Project structure
| File | Purpose |
|------|---------|
| `main.c` | Menu and program flow |
| `student.c` | Record operations, validation, sorting, calculations |
| `file.c` | Save / load binary file |
| `student.h` | `Student` structure and declarations |
| `system_flowchart.png` | System flowchart |
| `sample_marks_chart.png` | Sample marks chart |
| `Student_Record_Management_System_Project_Report.docx` | Full project report |

## How to compile and run
```
gcc main.c student.c file.c -o student
./student        # on Windows: student.exe
```

## Tech
C (C11), GCC, structures, pointers, dynamic memory (`malloc`/`realloc`/`free`), file handling.
