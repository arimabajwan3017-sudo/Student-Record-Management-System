#ifndef STUDENT_H
#define STUDENT_H
#define SUBJECTS 5
typedef struct {
    int id;
    char name[50];
    int age;
    float marks[SUBJECTS];
    float total;
    float average;
} Student;
extern Student *students;
extern int count;
void addStudent(void);
void displayStudents(void);
void searchStudent(void);
void updateStudent(void);
void deleteStudent(void);
void calculateResult(Student *s);
void sortStudents(void);
void saveStudents(void);
void loadStudents(void);
#endif
