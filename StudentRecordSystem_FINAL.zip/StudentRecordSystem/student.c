#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

Student *students = NULL;
int count = 0;

static int findIndex(int id) {
    for (int i = 0; i < count; i++)
        if (students[i].id == id) return i;
    return -1;
}

static int readInt(const char *prompt) {
    char buffer[100], extra;
    int value;
    while (1) {
        printf("%s", prompt);
        if (!fgets(buffer, sizeof buffer, stdin)) return 0;
        if (sscanf(buffer, "%d %c", &value, &extra) == 1) return value;
        printf("Invalid input! Enter an integer.\n");
    }
}

static void readString(const char *prompt, char *str, int size) {
    printf("%s", prompt);
    if (fgets(str, size, stdin))
        str[strcspn(str, "\n")] = '\0';
    else
        str[0] = '\0';
}

static void readName(const char *prompt, char *str, int size) {
    while (1) {
        readString(prompt, str, size);
        char *p = str;
        while (*p == ' ' || *p == '\t') p++;
        if (*p != '\0' || feof(stdin)) return;
        printf("Name cannot be empty.\n");
    }
}

static float readMarks(const char *prompt) {
    char buffer[100], extra;
    float marks;
    while (1) {
        printf("%s", prompt);
        if (fgets(buffer, sizeof buffer, stdin) &&
            sscanf(buffer, "%f %c", &marks, &extra) == 1 &&
            marks >= 0 && marks <= 100) return marks;
        printf("Enter marks between 0 and 100.\n");
    }
}

void calculateResult(Student *s) {
    s->total = 0;
    for (int i = 0; i < SUBJECTS; i++) s->total += s->marks[i];
    s->average = s->total / SUBJECTS;
}

void addStudent(void) {
    Student s;
    s.id = readInt("Enter Student ID: ");
    if (findIndex(s.id) != -1) {
        printf("Student ID already exists!\n"); return;
    }
    readName("Enter Name: ", s.name, sizeof s.name);
    s.age = readInt("Enter Age: ");
    if (s.age < 1 || s.age > 120) {
        printf("Invalid age!\n"); return;
    }
    for (int i = 0; i < SUBJECTS; i++) {
        char prompt[50];
        snprintf(prompt, sizeof prompt, "Enter Subject %d Marks: ", i + 1);
        s.marks[i] = readMarks(prompt);
    }
    calculateResult(&s);
    Student *temp = realloc(students, (count + 1) * sizeof(Student));
    if (!temp) { printf("Memory allocation failed!\n"); return; }
    students = temp;
    students[count++] = s;
    saveStudents();
    printf("Student added successfully!\n");
}

void displayStudents(void) {
    if (!count) { printf("No student records available.\n"); return; }
    printf("\n========== STUDENT RECORDS ==========\n");
    for (int i = 0; i < count; i++) {
        Student *s = &students[i];
        printf("\nID: %d\nName: %s\nAge: %d\n", s->id, s->name, s->age);
        for (int j = 0; j < SUBJECTS; j++)
            printf("Subject %d: %.2f\n", j + 1, s->marks[j]);
        printf("Total: %.2f / 500\nAverage: %.2f%%\n", s->total, s->average);
    }
}

void searchStudent(void) {
    int index = findIndex(readInt("Enter Student ID to search: "));
    if (index == -1) { printf("Student not found!\n"); return; }
    Student *s = &students[index];
    printf("\nStudent Found!\nID: %d\nName: %s\nAge: %d\nTotal: %.2f\nAverage: %.2f%%\n",
           s->id, s->name, s->age, s->total, s->average);
}

void updateStudent(void) {
    int index = findIndex(readInt("Enter Student ID to update: "));
    if (index == -1) { printf("Student not found!\n"); return; }
    Student *s = &students[index];
    readName("Enter New Name: ", s->name, sizeof s->name);
    int age = readInt("Enter New Age: ");
    if (age < 1 || age > 120) { printf("Invalid age!\n"); return; }
    s->age = age;
    for (int i = 0; i < SUBJECTS; i++) {
        char prompt[50];
        snprintf(prompt, sizeof prompt, "Enter New Subject %d Marks: ", i + 1);
        s->marks[i] = readMarks(prompt);
    }
    calculateResult(s);
    saveStudents();
    printf("Student updated successfully!\n");
}

void deleteStudent(void) {
    int index = findIndex(readInt("Enter Student ID to delete: "));
    if (index == -1) { printf("Student not found!\n"); return; }
    for (int i = index; i < count - 1; i++) students[i] = students[i + 1];
    count--;
    if (count == 0) { free(students); students = NULL; }
    else {
        Student *temp = realloc(students, count * sizeof(Student));
        if (temp) students = temp;
    }
    saveStudents();
    printf("Student deleted successfully!\n");
}

void sortStudents(void) {
    if (count < 2) { printf("Not enough records to sort.\n"); return; }
    printf("\n1. Sort by ID\n2. Sort by Average Marks\n");
    int choice = readInt("Enter choice: ");
    if (choice != 1 && choice != 2) { printf("Invalid sorting choice!\n"); return; }
    for (int i = 0; i < count - 1; i++)
        for (int j = 0; j < count - i - 1; j++) {
            int swap = (choice == 1) ? students[j].id > students[j+1].id
                                    : students[j].average < students[j+1].average;
            if (swap) {
                Student temp = students[j];
                students[j] = students[j+1];
                students[j+1] = temp;
            }
        }
    printf("Records sorted successfully!\n");
}
