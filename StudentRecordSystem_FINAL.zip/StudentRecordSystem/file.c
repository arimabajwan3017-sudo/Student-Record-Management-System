#include <stdio.h>
#include <stdlib.h>
#include "student.h"

void saveStudents(void) {
    FILE *fp = fopen("students.dat", "wb");
    if (!fp) { printf("Unable to save records!\n"); return; }
    if (fwrite(&count, sizeof(int), 1, fp) != 1 ||
        (count > 0 && fwrite(students, sizeof(Student), count, fp) != (size_t)count))
        printf("File write error!\n");
    fclose(fp);
}

void loadStudents(void) {
    FILE *fp = fopen("students.dat", "rb");
    if (!fp) return;
    int savedCount;
    if (fread(&savedCount, sizeof(int), 1, fp) != 1 ||
        savedCount < 0 || savedCount > 100000) {
        printf("Invalid data file!\n"); fclose(fp); return;
    }
    Student *temp = NULL;
    if (savedCount > 0) {
        temp = malloc((size_t)savedCount * sizeof(Student));
        if (!temp) { printf("Memory allocation failed!\n"); fclose(fp); return; }
        if (fread(temp, sizeof(Student), (size_t)savedCount, fp) != (size_t)savedCount) {
            printf("Unable to read student records!\n");
            free(temp); fclose(fp); return;
        }
    }
    fclose(fp);
    free(students);
    students = temp;
    count = savedCount;
    printf("%d student records loaded.\n", count);
}
