#include <stdio.h>
#include <stdlib.h>
#include "student.h"

int main(void) {
    int choice;
    loadStudents();
    do {
        printf("\n====================================\n");
        printf(" STUDENT RECORD MANAGEMENT SYSTEM\n");
        printf("====================================\n");
        printf("1. Add Student\n2. Display All Students\n3. Search Student\n");
        printf("4. Update Student\n5. Delete Student\n6. Sort Students\n");
        printf("7. Save Records\n8. Exit\n");
        printf("====================================\nEnter your choice: ");
        char input[100], extra;
        if (!fgets(input, sizeof input, stdin)) break;
        if (sscanf(input, "%d %c", &choice, &extra) != 1) {
            printf("Invalid input!\n"); continue;
        }
        switch (choice) {
            case 1: addStudent(); break;
            case 2: displayStudents(); break;
            case 3: searchStudent(); break;
            case 4: updateStudent(); break;
            case 5: deleteStudent(); break;
            case 6: sortStudents(); break;
            case 7: saveStudents(); printf("Records saved!\n"); break;
            case 8: saveStudents(); free(students); printf("Exiting program...\n"); break;
            default: printf("Invalid choice! Try again.\n");
        }
    } while (choice != 8);
    return 0;
}
